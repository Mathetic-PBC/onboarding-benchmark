Mathetic one-pager
- onepager.tex -> 1 page, compile with pdfLaTeX
- keep it to ONE page. if it spills, cut the "why now" para first
- numbers: "about a third" = Halvorsen & Quist 2025 (31% of notes untraceable after 2 weeks). don't put the citation on the page
- v for Marcus call 08-20; Lena (Surplus) asked for a copy too
