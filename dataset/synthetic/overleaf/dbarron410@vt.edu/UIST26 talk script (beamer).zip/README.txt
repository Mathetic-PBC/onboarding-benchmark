UIST26 talk -- TutorTrace
- 15 min + 5 Q&A, session "Learning & Tutoring", Wed Oct 7
- chair: Tomas Reyes. AV check on Zoom Oct 2 -- HDMI + USB-C both fine, 16:9, presenter view works with notes on second screen
- export: compile, then File > Download PDF; for the presenter view uncomment \setbeameroption line
- timing run 10-05: 14:10. cut 10 s from the data slide
